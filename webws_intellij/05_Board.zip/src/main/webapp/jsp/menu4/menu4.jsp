<%--
  Created by IntelliJ IDEA.
  User: thrma
  Date: 2026-11-02
  Time: 오후 2:28
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>

    Menu4 Page
</body>
</html>
