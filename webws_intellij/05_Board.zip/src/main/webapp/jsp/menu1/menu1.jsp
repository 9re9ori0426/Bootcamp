<%--
  Created by IntelliJ IDEA.
  User: thrma
  Date: 2026-11-02
  Time: 오후 2:24
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>

    <h1>Menu1 Page</h1>
    <img src="static-img/스텔라이브-stellive.gif" alt="">

</body>
</html>
