
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/movie_detail.css">
</head>
<body>

<form action="edit" method="post" enctype="multipart/form-data">
<div>
    <div class="movie-detail">
        <div>
            <div class="col-1">No.</div>
            <div class="col-2"><input name="no" type="text" value="${movie.no}" readonly></div>
        </div>
        <div>
            <div><img src="${movie.img}" alt="">
                <input name="oldImg" type="text" value="${movie.img}" hidden="hidden">
                <input type="file" name="newImg"></div>
        </div>
        <div>
            <div class="col-1">Title.</div>
            <div class="col-2"><input name="title" type="text" value="${movie.title}"></div>
        </div>
        <div>
            <div class="col-1">Actor.</div>
            <div class="col-2"><input name="actor" type="text" value="${movie.actor}"></div>
        </div>
        <div>
            <div class="col-1">Story.</div>
            <div class="col-2"><textarea name="story" >${movie.story}</textarea></div>
        </div>
        <button class="movie-btn">done</button>
    </div>
    
    
    
</div>
</form>

</body>
</html>
