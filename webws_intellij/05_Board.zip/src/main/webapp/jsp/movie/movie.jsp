<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>


<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/card.css">
</head>
<body>

<section class="movie-add">
    <div class="movie-add-heading">
        <span>🎬 MOVIE RECORD</span>
        <h1>새로운 영화 담기</h1>
        <p>기억하고 싶은 영화 이야기를 남겨 주세요 ♡</p>
    </div>

    <form class="movie-add-form"
          action="movie"
          method="post"
          enctype="multipart/form-data">

        <div class="movie-add-row">
            <label class="movie-add-field">
                <span>🩵 영화 제목</span>
                <input type="text"
                       name="title"
                       placeholder="영화 제목을 입력해 주세요"
                       required>
            </label>

            <label class="movie-add-field">
                <span>☁️ 출연 배우</span>
                <input type="text"
                       name="actor"
                       placeholder="출연 배우를 입력해 주세요">
            </label>
        </div>

        <label class="movie-add-field">
            <span>📷 영화 포스터</span>
            <input type="file" name="file" accept="image/*">
            <small>영화를 소개할 포스터 이미지를 골라 주세요.</small>
        </label>

        <label class="movie-add-field">
            <span>📝 영화 이야기</span>
            <textarea name="story"
                      rows="5"
                      placeholder="영화의 줄거리나 기억에 남는 이야기를 적어 주세요"></textarea>
        </label>

        <div class="movie-add-actions">
            <button class="movie-add-button" type="submit">
                💛 영화 담기
            </button>
        </div>
    </form>
</section>

<div class="movie-browser">
    <!-- 이전 페이지 화살표 -->
    <button class="movie-arrow movie-arrow-prev"
            type="button"
            aria-label="이전 페이지"
            onclick="location.href='movie?p=${currentPage - 1}'"
    ${currentPage <= 1 ? 'disabled' : ''}>
        ◀
    </button>

<div class="movie-list">

    <c:forEach items="${movies}" var="movie">
        <article class="movie-card">
            <div class="movie-img" onclick="location.href='detail?no=' + ${movie.no}">
                <img src="${movie.img}" alt="영화 포스터">
            </div>

            <div class="movie-info">
                <h3 class="movie-title">
                    <c:out value="${movie.title}" />
                </h3>

                <p class="movie-actor">
                    <span>출연</span>
                    <c:out value="${movie.actor}" />
                </p>
               <div>
                   <button class="movie-btn" onclick="delMovie(${movie.no})">del</button>
                   <button class="movie-btn" onclick="location.href='update?no=${movie.no}'">수정(jsp)</button>
               </div>
                <div>
                   <button class="movie-btn" onclick="location.href='edit?no=${movie.no}'">수정(img]jsp)</button>
                   <button class="movie-btn" onclick="upMovie('${movie.title}', '${movie.actor}', ${movie.no})">수정(js)</button>
               </div>
            </div>
        </article>
    </c:forEach>
</div>
    <!-- 다음 페이지 화살표 -->
    <button class="movie-arrow movie-arrow-next"
            type="button"
            aria-label="다음 페이지"
            onclick="location.href='movie?p=${currentPage + 1}'"
    ${currentPage >= totalPage ? 'disabled' : ''}>
        ▶
    </button>
    <div class="movie-pagination">
        <button class="movie-btn-in"
                type="button"
                onclick="location.href='movie?p=${currentPage - 1}'"
        ${currentPage <= 1 ? 'disabled' : ''}>
            <span aria-hidden="true">‹</span> 이전
        </button>

        <button class="movie-btn-next"
                type="button"
                onclick="location.href='movie?p=${currentPage + 1}'"
        ${currentPage >= totalPage ? 'disabled' : ''}>
            다음 <span aria-hidden="true">›</span>
        </button>
    </div>

<%--    <div>--%>
<%--        <a href="movie?p=1">[begin]</a>--%>
<%--        <c:forEach begin="1" end="${totalPage}" var="i">--%>
<%--            <a href="movie?p=${i}">[${i}]</a>--%>
<%--        </c:forEach>--%>
<%--        <a href="movie?p=${totalPage}">[end]</a>--%>
<%--    </div>--%>
    <div class="movie-page-numbers">
        <a href="movie?p=1">처음</a>

        <c:forEach begin="1" end="${totalPage}" var="i">
            <a href="movie?p=${i}"
               class="${currentPage == i ? 'is-active' : ''}">
                    ${i}
            </a>
        </c:forEach>

        <c:if test="${totalPage > 0}">
            <a href="movie?p=${totalPage}">마지막</a>
        </c:if>
    </div>
<script>
    function delMovie(no) {
        let ok = confirm("really?")
        if (ok) {
            location.href = "delmovie?no=" + no;
        }
    }
</script>
<script>
    function upMovie(title, actor, no) {
        let title2 = prompt("edit title", title);
        let actor2 = prompt("edit actor", actor);
        if (title2 != "" && actor2 != "" && title2 != null && actor2 != null) {
            location.href = "update?title=" + title2 + "&actor=" + actor2 + "&no=" + no;
        }
    }
</script>
</body>
</html>
