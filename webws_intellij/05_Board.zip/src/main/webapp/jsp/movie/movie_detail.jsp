
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
    <link rel="stylesheet" href="css/movie_detail.css">
</head>
<body>

<div>
    <div class="movie-detail">
        <div>
            <div class="col-1">No.</div>
            <div class="col-2">${movie.no}</div>
        </div>
        <div>
            <div><img src="${movie.img}" alt=""></div>
        </div>
        <div>
            <div class="col-1">Title.</div>
            <div class="col-2">${movie.title}</div>
        </div>
        <div>
            <div class="col-1">Actor.</div>
            <div class="col-2">${movie.actor}</div>
        </div>
        <div>
            <div class="col-1">Story.</div>
            <div class="col-2">${movie.story}</div>
        </div>
    </div>
    
    
    
</div>


</body>
</html>
