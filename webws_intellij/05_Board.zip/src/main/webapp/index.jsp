<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>gi's World</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/content.css">
</head>
<body>

<div class="container">
    <header class="cute-header">
        <div class="title" onclick="location.href='index.jsp'" style="cursor: pointer">Gy's Place</div>

        <nav class="menu" aria-label="메인 메뉴">
            <ul>
                <li><a href="menu1">Menu1</a></li>
                <li><a href="movie">Movie</a></li>
                <li><a href="review">Review</a></li>
                <li><a href="menu4">Menu4</a></li>
            </ul>
        </nav>

        <img class="peek-chiikawa"
             src="css/chiikawa.png"
             alt="">
    </header>

    <main class="content">
        <div class="section-heading hachi-heading">
            <div class="heading-text">
                <span class="section-badge">🩵 MOVIE</span>
                <h2>오늘은 어떤 영화를 볼까?</h2>
                <p>좋아하는 영화와 함께하는 작은 휴식 ♡</p>
            </div>

            <img class="peek-hachiware"
                 src="${pageContext.request.contextPath}/static-img/hachiware.png"
                 alt="">
        </div>

        <div class="content-body">
            <jsp:include page="${content}" />
        </div>
    </main>

    <footer class="cute-footer usagi-footer">
        <div class="footer-text">
            <span class="footer-badge">💛 HAVE A NICE DAY</span>

            <div class="footer-brand">Gy's Place ♡</div>
            <p>작고 소중한 순간을 차곡차곡 담아요.</p>

            <div class="footer-bottom">
                © Gy's Place · 오늘도 즐거운 하루 보내세요!
            </div>
        </div>

        <img class="peek-usagi"
             src="${pageContext.request.contextPath}/static-img/usagi.png"
             alt="">
    </footer>
</div>


</body>
</html>