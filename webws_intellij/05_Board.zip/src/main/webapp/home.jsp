<%--
  Created by IntelliJ IDEA.
  User: thrma
  Date: 2026-11-02
  Time: 오후 2:17
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>

<img src="static-img/ratias.gif" alt="" >


</body>
</html>
