package com.gi.board.movie;

import com.gi.board.main.DBManager;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class MovieDAO {

    public static final MovieDAO MDAO = new MovieDAO();

    private MovieDAO() {
    }


    private  ArrayList<MovieDTO> movies;
    // 전체조회
    public void selectAllMovie(HttpServletRequest request) {
        // 1. db

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        String sql = "select * from MOVIE_TEST";
        try {
            con = DBManager.connect();
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            movies = new ArrayList<>();
            MovieDTO movie = null;
            while (rs.next()) {
                int no = rs.getInt("m_no");
                String title = rs.getString("m_title");
                String actor = rs.getString("m_actor");
                String img = rs.getString("m_img");
                String story = rs.getString("m_story");
                movie = new MovieDTO(no, title, actor, img, story);
                movies.add(movie);
            }
//            request.setAttribute("movies", movies);

        } catch (Exception e){
            e.printStackTrace();
        }finally {
            DBManager.close(con,pst,rs);
        }
    }

    public void addMovie(HttpServletRequest request) {
        Connection con = null;
        PreparedStatement pst = null;
        String sql = "insert into MOVIE_TEST values (MOVIE_TEST_SEQ.nextval, ?,?,?,?)";
        try {
            String savePath = request.getServletContext().getRealPath("movieFile");
            System.out.println(savePath);
            MultipartRequest mr = new MultipartRequest(request, savePath, 1024*1024*30,
            "utf-8", new DefaultFileRenamePolicy());
            con = DBManager.connect();
            pst = con.prepareStatement(sql);
            String title = mr.getParameter("title");
            String actor = mr.getParameter("actor");
            String img = mr.getFilesystemName("file");
            if (img == null) {
                img = "static-img/default_movie.jpg";
            } else {
            img = "movieFile/" + img;

            }
            String story = mr.getParameter("story");
            pst.setString(1, title);
            pst.setString(2, actor);
            pst.setString(3, img);
            pst.setString(4, story);

            if (pst.executeUpdate() == 1) {
                System.out.println("added successfully");
            }



        } catch (Exception e){
            e.printStackTrace();
        }finally {
            DBManager.close(con,pst,null);
        }
    }

    public void selectMovie(HttpServletRequest request) {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        String sql = "select * from MOVIE_TEST where m_no=?";
        try {
            con = DBManager.connect();
            pst = con.prepareStatement(sql);
            pst.setString(1, request.getParameter("no"));
            rs = pst.executeQuery();
            MovieDTO movie = null;
            if (rs.next()) {
                int no = rs.getInt("m_no");
                String title = rs.getString("m_title");
                String actor = rs.getString("m_actor");
                String img = rs.getString("m_img");
                String story = rs.getString("m_story");
                movie = new MovieDTO(no, title, actor, img, story);

            }
            request.setAttribute("movie", movie);

        } catch (Exception e){
            e.printStackTrace();
        }finally {
            DBManager.close(con,pst,rs);
        }
    }

    public void delMovie(HttpServletRequest request) {
        Connection con = null;
        PreparedStatement pst = null;
        String sql = "delete from MOVIE_TEST where m_no=?";
        try {
            con = DBManager.connect();
            pst = con.prepareStatement(sql);
            pst.setString(1, request.getParameter("no"));

            if (pst.executeUpdate() == 1) {
                System.out.println("deleted successfully");
            }

        } catch (Exception e){
            e.printStackTrace();
        }finally {
            DBManager.close(con,pst,null);
        }


    }

    public void updateMovie(HttpServletRequest request) {
        Connection con = null;
        PreparedStatement pst = null;
        String sql = "update MOVIE_TEST set M_TITLE=?, M_ACTOR=?";
        if (request.getParameter("story") != null) {
            sql += "m_story=? where m_no=?";
        }else {
            sql += "where m_no=?";
        }



        try {
            con = DBManager.connect();
            pst = con.prepareStatement(sql);
            pst.setString(1, request.getParameter("title"));
            pst.setString(2, request.getParameter("actor"));

            if (request.getParameter("story") != null) {
            pst.setString(3, request.getParameter("story"));
            pst.setString(4, request.getParameter("no"));
            }else {

                pst.setString(3, request.getParameter("no"));
            }


            if (pst.executeUpdate() == 1) {
                System.out.println("update successfully");
            }

        } catch (Exception e){
            e.printStackTrace();
        }finally {
            DBManager.close(con,pst,null);
        }
    }

    public void editMovie(HttpServletRequest request) {
        Connection con = null;
        PreparedStatement pst = null;
        String sql = "update MOVIE_TEST set m_title=?, m_actor=?, m_img=?, m_story=? where m_no=?";
        try {
            String savePath = request.getServletContext().getRealPath("movieFile");
            System.out.println(savePath);
            MultipartRequest mr = new MultipartRequest(request, savePath, 1024*1024*30,
                    "utf-8", new DefaultFileRenamePolicy());
            con = DBManager.connect();
            pst = con.prepareStatement(sql);

            String title = mr.getParameter("title");
            String actor = mr.getParameter("actor");

            String oldImg = mr.getParameter("oldImg");
            String newImg = mr.getFilesystemName("newImg");
            String img = "movieFile/" + newImg;
            if (newImg == null) {
                img = oldImg;
            }

            String story = mr.getParameter("story");
            String no = mr.getParameter("no");

            pst.setString(1, title);
            pst.setString(2, actor);
            pst.setString(3, img);
            pst.setString(4, story);
            pst.setString(5, no);

            if (pst.executeUpdate() == 1) {
                System.out.println("edit successfully");
                if (newImg != null) {
                    File file = new File(savePath + "/" + oldImg);
                    file.delete();
                }
                request.setAttribute("no", no);
            }



        } catch (Exception e){
            e.printStackTrace();
        }finally {
            DBManager.close(con,pst,null);
        }

    }

    public void paging(int pageNum, HttpServletRequest request) {
        request.setAttribute("currentPage", pageNum);
        int total = movies.size();
        int count = 3;


        int totalPage = (int) Math.ceil((double)total / count);
        request.setAttribute("totalPage", totalPage);

        int start = total - (count * (pageNum - 1));
        int end = (pageNum == totalPage) ? -1 : start - (count + 1);

        ArrayList<MovieDTO> items = new ArrayList<>();
        for (int i = start -1; i > end; i--) {
            items.add(movies.get(i));
        }

        request.setAttribute("movies", items);

    }

}
