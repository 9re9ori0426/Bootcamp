package com.gi.board.movie;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/update")
public class MovieUpC extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String title = request.getParameter("title");
        if (title != null) {
//            MovieDAO.updateMovie(request);
            MovieDAO.MDAO.updateMovie(request);
            response.sendRedirect("movie");
        }else {

//        MovieDAO.selectMovie(request);

            MovieDAO.MDAO.selectMovie(request);
        request.setAttribute("content", "jsp/movie/movie_up.jsp");
        request.getRequestDispatcher("index.jsp").forward(request,response);
        }




    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        // 등록하는 일
        request.setCharacterEncoding("utf-8");
//        MovieDAO.updateMovie(request);

        MovieDAO.MDAO.updateMovie(request);
        response.sendRedirect("detail?no=" + request.getParameter("no"));
    }
}