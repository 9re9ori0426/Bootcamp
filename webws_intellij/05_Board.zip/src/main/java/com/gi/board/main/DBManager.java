package com.gi.board.main;

import java.sql.*;

public class DBManager {

    public static Connection connect() throws SQLException {
        String url = "jdbc:oracle:thin:@192.168.1.122:1521:XE";

        return DriverManager.getConnection(url,"c##gy1004","gy1004");

    }

    public static void close(Connection conn, PreparedStatement pstmt, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
            pstmt.close();
            }
            conn.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
